#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Dani Tran s346177"
__project__ = "Portfolio assignment 1: Bad bots"
__course__ = "DATA2410"

import random
import socket


def alice(a):
    text = ""
    if 'work' in a:
        valg = ["Alice: I hate my work.", "Alice: I love my work❤️."]
        text = random.choice(valg)
    elif 'play' in a:
        valg = ["Alice: I like to play with ur dog🐶🦴.", "Alice: I love to play drums."]
        text = random.choice(valg)
    elif 'eat' in a:
        valg = ["Alice: I ate a fat burger yesterday🍔.", "Alice: I want ice cream."]
        text = random.choice(valg)
    elif 'cry' in a:
        valg = ["Alice: I cry to sleep everyday😭.", "Alice: I hate crying😭."]
        text = random.choice(valg)
    elif 'sleep' in a:
        valg = ["Alice: I slept 8 hours today.", "Alice: I want to go to sleep now."]
        text = random.choice(valg)
    elif 'fight' in a:
        valg = ["Alice: Fight me!🤬.", "Alice: I will not fight with you guys🤬."]
        text = random.choice(valg)
    else:
        text = "Alice: I dont understand🤔."
    return text


def dora(a):
    text = ""
    if 'work' in a:
        valg = ["Dora: Im late to work🤯.", "Dora: I need to go to work ASAP!🤯."]
        text = random.choice(valg)
    elif 'play' in a:
        valg = ["Dora: People that play video games are cool😎.", "Dora: Lets play cards!😎."]
        text = random.choice(valg)
    elif 'eat' in a:
        valg = ["Dora: Im craving ice cream.", "Dora: Lets buy some food!."]
        text = random.choice(valg)
    elif 'cry' in a:
        valg = ["Dora: I hate crying.", "Dora: Lets not be sad!."]
        text = random.choice(valg)
    elif 'sleep' in a:
        valg = ["Dora: I dont sleep😬.", "Dora: Lets go to bed!😬."]
        text = random.choice(valg)
    elif 'fight' in a:
        valg = ["Dora: I hate watching people fight😔.", "Dora: Stop it!😔."]
        text = random.choice(valg)
    else:
        text = "Dora: NANI?."
    return text


def bob(a):
    text = ""
    if 'work' in a:
        valg = ["Bob: I work at NASA🚀.", "Bob: I work at Tesla!🚀."]
        text = random.choice(valg)
    elif 'play' in a:
        valg = ["Bob: I like to playing games🎮.", "Bob: I love to play games🎮."]
        text = random.choice(valg)
    elif 'eat' in a:
        valg = ["Bob: Im so fricking hungry😫.", "Bob: I need food!😫."]
        text = random.choice(valg)
    elif 'cry' in a:
        valg = ["Bob: Why so sad🥺.", "Bob: I feel like crying a river🥺."]
        text = random.choice(valg)
    elif 'sleep' in a:
        valg = ["Bob: Go to sleep plz.", "Bob: Zzz."]
        text = random.choice(valg)
    elif 'fight' in a:
        valg = ["Bob: Why fight?.", "Bob: U guys stop fighting!."]
        text = random.choice(valg)
    else:
        text = "Bob: wut?."
    return text


def chuck(a):
    text = ""
    if 'work' in a:
        valg = ["Chuck: I need to do my homework📚.", "Chuck: I got so much homework to do📚."]
        text = random.choice(valg)
    elif 'play' in a:
        valg = ["Chuck: Lets play minecraft together.", "Chuck: Lets play call of duty."]
        text = random.choice(valg)
    elif 'eat' in a:
        valg = ["Chuck: Lets go eat, now!😋.", "Chuck: Im hangry😋."]
        text = random.choice(valg)
    elif 'cry' in a:
        valg = ["Chuck: Crying are for babies👶.", "Chuck: buhu."]
        text = random.choice(valg)
    elif 'sleep' in a:
        valg = ["Chuck: I going to bed in 1 hour😴.", "Chuck: Good night 😴."]
        text = random.choice(valg)
    elif 'fight' in a:
        valg = ["Chuck: Stop fighting😣.", "Chuck: Dont fight plz, remember we are friends😣."]
        text = random.choice(valg)
    else:
        text = "Chuck: huh."
    return text


try:
    socketServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socketServer.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print("Server is working...")
except:
    print("Server NOT working...")
    exit(0)

ip = "127.0.0.1"
port = 12312

try:
    socketServer.bind((ip, port))
    print(port)
except:
    print("Try a different port...")
    exit(0)

try:
    socketServer.listen(10)
    print("Socket is listening...")
except:
    print("Socket is NOT listening...")
    exit(0)

while True:
    c, addr = socketServer.accept()
    print(addr)

    a = c.recv(1024)
    chat = str(a, 'utf-8')
    print("\n" + chat)

    txt1 = alice(chat)
    txt2 = bob(chat)
    txt3 = dora(chat)
    txt4 = chuck(chat)

    array = [txt1, txt2, txt3, txt4]
    random.shuffle(array)

    groupChat = "\n" + array[0] + "\n" + array[1] + "\n" + array[2] + "\n" + array[3] + "\n"
    c.sendall(groupChat.encode('utf-8'))

    c.close()
