#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Dani Tran s346177"
__project__ = "Portfolio assignment 1: Bad bots"
__course__ = "DATA2410"

import random
import socket
import time

c = None
port = None

while True:
    try:
        socketClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Client is running...")
    except:
        print("Client NOT working...")
        exit(0)

    ip = "127.0.0.1"
    port = 12312

    try:
        socketClient.connect((ip, port))
    except:
        print("Client cant connect...")
        exit(0)

    action = input("Use one of these words: work, play, eat, cry, sleep, fight. Write exit to end the process.\n")
    socketClient.sendall(action.encode('utf-8'))

    if action == "exit" or action == "Exit":
        socketClient.close()
        print("\nProcess ending...")
        exit(0)

    serverChat = socketClient.recv(1024)
    chat = str(serverChat, 'utf-8')

    print("\nMessage: " + action)

    output = chat.split(".")
    tider = [0.5, 1, 3]

    print(output[0])
    time.sleep(random.choice(tider))
    print(output[1])
    time.sleep(random.choice(tider))
    print(output[2])
    time.sleep(random.choice(tider))
    print(output[3])
    print()

    socketClient.close()
